"""Whiten the background of each figure PNG.

Pixels are considered "background" when both:
  - low saturation  (S < sat_thresh)   -- greyish paper tone, not ink
  - luminance above lum_thresh          -- light, not black/red/green/blue

Resulting background is pure white; ink and accent hues preserved.
"""

from pathlib import Path
from PIL import Image

FIG_DIR = Path("/home/elaref/research/tifs/paper/figures")
SAT_THRESH = 35    # 0..255
LUM_THRESH = 215   # 0..255


def whiten(path: Path) -> None:
    img = Image.open(path).convert("RGBA")
    hsv = img.convert("HSV")
    sat = hsv.split()[1].load()
    val = hsv.split()[2].load()
    pix = img.load()
    w, h = img.size
    out = Image.new("RGBA", (w, h), (255, 255, 255, 255))
    out_pix = out.load()
    for y in range(h):
        for x in range(w):
            if sat[x, y] < SAT_THRESH and val[x, y] >= LUM_THRESH:
                out_pix[x, y] = (255, 255, 255, 255)
            else:
                out_pix[x, y] = pix[x, y]
    out.save(path, optimize=True)
    print(f"whitened  {path.name}  ({w}x{h})")


def main() -> None:
    for p in sorted(FIG_DIR.glob("fig_*.png")):
        whiten(p)


if __name__ == "__main__":
    main()
